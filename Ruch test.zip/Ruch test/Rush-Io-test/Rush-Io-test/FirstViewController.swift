//
//  FirstViewController.swift
//  Rush-Io-test
//
//  Created by Floren HENRI on 2/13/16.
//  Copyright © 2016 fhenri. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

var test = 0

class FirstViewController: UIViewController, CLLocationManagerDelegate , MKMapViewDelegate
{
    
    @IBOutlet weak var My_map: MKMapView!
    @IBOutlet weak var my_seg_switch: UISegmentedControl!
    @IBOutlet weak var My_geo: UIButton!

    
    var manager:CLLocationManager!
    var myLocations: [CLLocation] = []
    var Ecole42 : CLLocationCoordinate2D?
    var RERC : CLLocationCoordinate2D?
    var Metro_1 : CLLocationCoordinate2D?
    var bar : CLLocationCoordinate2D?
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        manager = CLLocationManager()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.requestAlwaysAuthorization()
        manager.startUpdatingLocation()
        My_map.delegate = self
        My_map.showsUserLocation = true
        My_map.mapType = MKMapType.Hybrid
        
        self.Ecole42 = CLLocationCoordinate2DMake(48.896466, 2.318488)
        let dropPin = MKPointAnnotation()
        dropPin.coordinate = self.Ecole42!
        dropPin.title = "42"
        dropPin.subtitle = "Ecole de ouf !"
        My_map.addAnnotation(dropPin)
        
        self.RERC = CLLocationCoordinate2DMake(48.894290, 2.313821)
        let dropPin1 = MKPointAnnotation()
        dropPin1.coordinate = self.RERC!
        dropPin1.title = "RERC"
        dropPin1.subtitle = "RER pour rentrer cher moi!"
        My_map.addAnnotation(dropPin1)
        
        self.Metro_1 = CLLocationCoordinate2DMake(48.891787, 2.238366)
        let dropPin2 = MKPointAnnotation()
        dropPin2.coordinate = self.Metro_1!
        dropPin2.title = "Metro_1"
        dropPin2.subtitle = "Metro de la defense"
        My_map.addAnnotation(dropPin2)
        
        self.bar = CLLocationCoordinate2DMake(48.881522, 2.272544)
        let dropPin3 = MKPointAnnotation()
        dropPin3.coordinate = self.bar!
        dropPin3.title = "Bar"
        dropPin3.subtitle = "Bar le plus brancher de paris"
        My_map.addAnnotation(dropPin3)
      
    }
    
    
    @IBAction func My_geo_func(sender: AnyObject)
    {
        let span = MKCoordinateSpanMake(0.0008, 0.0008)
        let idf = MKCoordinateRegion(center: self.Ecole42!, span: span)
        My_map.setRegion(idf, animated:true)
    }
    
    @IBAction func My_switch(sender: UISegmentedControl)
    
        {
            
            switch my_seg_switch.selectedSegmentIndex
            {
            case 0:
                My_map.mapType = MKMapType.Standard
            case 1:
                My_map.mapType = MKMapType.Hybrid
            case 2:
                My_map.mapType = MKMapType.Satellite
            default :
                break
            }
        }
    
    func test(pinNumber : Int)
    {
        let span = MKCoordinateSpanMake(0.0008, 0.0008)
        if (pinNumber == 0)
        {
            let idf = MKCoordinateRegion(center: self.RERC!, span: span)
            My_map.setRegion(idf, animated:true)
        }
        if (pinNumber == 1)
        {
            
            let idf = MKCoordinateRegion(center: self.Metro_1!, span: span)
            My_map.setRegion(idf, animated:true)
        }
        if (pinNumber == 2)
        {
            let idf = MKCoordinateRegion(center: self.bar!, span: span)
            My_map.setRegion(idf, animated:true)
        }

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
