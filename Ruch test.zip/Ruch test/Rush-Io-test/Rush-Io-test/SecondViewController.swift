//
//  SecondViewController.swift
//  Rush-Io-test
//
//  Created by Floren HENRI on 2/13/16.
//  Copyright © 2016 fhenri. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation


class SecondViewController: UIViewController, CLLocationManagerDelegate {

    @IBOutlet weak var tableView: UITableView!
    
    
    var items: [String] = ["RERC", "Metro 1", "Bar-brancher"]
    var delegateFirstView : FirstViewController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: "cell")
      
        
        for it in items
        {
            if it == "RERC"
            {
             let dropPin1 = MKPointAnnotation()
             let RERC = CLLocationCoordinate2DMake(48.894290, 2.313821)
            // let span = MKCoordinateSpanMake(0.0008, 0.0008)
            // let idf = MKCoordinateRegion(center: RERC, span: span)
             dropPin1.coordinate = RERC
             dropPin1.title = "RERC"
            }
            
            else if it == "Metro 1"
            {
                let dropPin2 = MKPointAnnotation()
                let Metro1 = CLLocationCoordinate2DMake(48.891799, 2.237990)
                //let span = MKCoordinateSpanMake(0.0008, 0.0008)
                //let idf = MKCoordinateRegion(center: Metro1, span: span)
                dropPin2.coordinate = Metro1
                dropPin2.title = "Metro 1"
            }
            else if it == "Bar-brancher"
            {
                let dropPin3 = MKPointAnnotation()
                let Bar = CLLocationCoordinate2DMake(48.891799, 2.237990)
          //      let span = MKCoordinateSpanMake(0.0008, 0.0008)
              //  let idf = MKCoordinateRegion(center: Bar, span: span)
                dropPin3.coordinate = Bar
                dropPin3.title = "Bar-brancher"
            }
            let tabbarViewControllers = self.tabBarController?.viewControllers
            self.delegateFirstView = tabbarViewControllers![0] as? FirstViewController
        }
        
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.items.count;
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell:UITableViewCell = self.tableView.dequeueReusableCellWithIdentifier("cell")!as UITableViewCell
        
        cell.textLabel?.text = self.items[indexPath.row]
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        self.tabBarController!.selectedIndex = 0;
        print("You selected cell #\(indexPath.row)!")
        self.delegateFirstView?.test(indexPath.row)
        self.tabBarController!.selectedIndex = 0
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}